******************************
sorl-thumbnail's documentation
******************************

Contents:

.. toctree::
   :maxdepth: 2

   examples
   installation
   requirements
   template
   management
   logging
   operation
   reference/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

