from .default import *


THUMBNAIL_ENGINE = 'sorl.thumbnail.engines.pgmagick_engine.Engine'
