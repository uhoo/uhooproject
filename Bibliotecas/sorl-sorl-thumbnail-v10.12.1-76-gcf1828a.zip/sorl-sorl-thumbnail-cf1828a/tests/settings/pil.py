from .default import *


THUMBNAIL_ENGINE = 'sorl.thumbnail.engines.pil_engine.Engine'
