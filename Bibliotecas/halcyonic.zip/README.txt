Halcyonic 1.0 by nodethirtythree + FCT
http://nodethirtythree.com | @nodethirtythree
Released under the Creative Commons Attribution 3.0 license (nodethirtythree.com/license)

This is Halcyonic, a free HTML5 + CSS3 website template by nodethirtythree for FCT (freecsstemplates.org).
It's lightweight and fully responsive with support for wide, standard, and mobile displays.

Halcyonic is my second test design based on 5grid (0.2), a responsive, grid-based HTML5+CSS3 design framework
I've been developing. If you want to give it a go for yourself, you can download it here:

http://nodethirtythree.com/5grid/

Feedback, bug reports, and comments are not only welcome, but strongly encouraged :)

- AJ (@nodethirtythree)


PS: To see what Halccyonic looks like in 1000px and mobile, just shrink your browser window -- you'll see
the alternate styles kick in automatically.