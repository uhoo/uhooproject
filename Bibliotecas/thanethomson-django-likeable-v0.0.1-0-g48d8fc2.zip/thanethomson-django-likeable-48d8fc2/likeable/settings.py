#
# django-likeable
#
# See LICENSE for licensing details.
#

from django.conf import settings


DEFAULT_LIKE_BACK_URL = getattr(settings, 'DEFAULT_LIKE_BACK_URL', '/')

