from django.contrib.comments.templatetags.comments import *
