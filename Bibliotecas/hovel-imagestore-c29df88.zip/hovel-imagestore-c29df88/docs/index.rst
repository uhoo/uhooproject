Imagestore. Gallery solution for django projects
================================================

Contents:
---------

.. toctree::
   :maxdepth: 2

   install
   settings
   extending
   example
   djangocms
   watermark

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

