Watermarking
============

Use `watermarker <http://pypi.python.org/pypi/watermarker/>`__ sorl integration to add watermark to your images