Example project
===============

Package contatins preconfigured django project with installed imagestore.
You can find it in `test` directory inside project root,
or get from `repository <https://bitbucket.org/zeus/imagestore/src>`_
