class LikesNotEnabledException(Exception):
    pass


class CannotVoteException(Exception):
    pass
